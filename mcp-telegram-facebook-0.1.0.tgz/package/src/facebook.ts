import { readFile, stat } from "node:fs/promises";
import { basename } from "node:path";
import { config, requireFacebook } from "./config.js";

const GRAPH_BASE = () => `https://graph.facebook.com/${config.facebook.graphVersion}`;

interface GraphError {
  error?: { message?: string; type?: string; code?: number; error_subcode?: number };
}

async function graphRequest<T = unknown>(
  path: string,
  options: {
    method?: "GET" | "POST" | "DELETE";
    params?: Record<string, string | number | boolean | undefined>;
  } = {}
): Promise<T> {
  requireFacebook();
  const method = options.method ?? "GET";
  const url = new URL(`${GRAPH_BASE()}/${path.replace(/^\//, "")}`);
  const params = Object.entries(options.params ?? {}).filter(([, value]) => value !== undefined);
  const headers: Record<string, string> = { Accept: "application/json" };
  let body: URLSearchParams | undefined;

  if (method === "GET") {
    for (const [key, value] of params) url.searchParams.set(key, String(value));
  } else {
    body = new URLSearchParams();
    for (const [key, value] of params) body.set(key, String(value));
    headers["Content-Type"] = "application/x-www-form-urlencoded";
  }
  headers.Authorization = `Bearer ${config.facebook.accessToken}`;

  const res = await fetch(url, { method, headers, body });

  const text = await res.text();
  let data: unknown;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }

  if (!res.ok) {
    const err = (data as GraphError).error;
    throw new Error(
      `Erreur Graph API (${res.status})${err?.code ? ` [code ${err.code}]` : ""}: ` +
        `${err?.message ?? text}`
    );
  }
  return data as T;
}

/* ----------------------------- Pages ----------------------------- */

export async function listPages(): Promise<unknown> {
  return graphRequest("me/accounts", {
    params: { fields: "id,name,category,access_token,tasks" },
  });
}

export async function getPageInsights(pageId: string, metrics: string, period = "day"): Promise<unknown> {
  return graphRequest(`${pageId}/insights`, {
    params: { metric: metrics, period },
  });
}

/**
 * Publie une vidéo locale sur une Page Facebook, avec description personnalisée.
 * Utilise l'upload multipart standard (adapté aux vidéos jusqu'à ~1 Go).
 */
export async function postVideoToPage(args: {
  pageId?: string;
  filePath: string;
  description?: string;
  title?: string;
  pageAccessToken?: string;
}): Promise<unknown> {
  requireFacebook();
  const pageId = args.pageId || config.facebook.pageId;
  if (!pageId) {
    throw new Error(
      "Aucune Page cible : passez `pageId` ou définissez FACEBOOK_PAGE_ID dans le .env."
    );
  }

  await stat(args.filePath); // vérifie l'existence, lève une erreur claire sinon
  const fileBuffer = await readFile(args.filePath);
  const blob = new Blob([fileBuffer], { type: "video/mp4" });

  const form = new FormData();
  form.append("source", blob, basename(args.filePath));
  if (args.description) form.append("description", args.description);
  if (args.title) form.append("title", args.title);

  // Une Page doit utiliser son propre Page Access Token pour publier.
  const token = args.pageAccessToken || config.facebook.accessToken;

  const url = new URL(`${GRAPH_BASE()}/${pageId}/videos`);
  url.searchParams.set("access_token", token);

  const res = await fetch(url, { method: "POST", body: form });
  const text = await res.text();
  let data: unknown;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }
  if (!res.ok) {
    const err = (data as GraphError).error;
    throw new Error(`Échec de la publication vidéo (${res.status}): ${err?.message ?? text}`);
  }
  return data;
}

/** Publie un simple post texte (avec lien optionnel) sur une Page. */
export async function postToPageFeed(args: {
  pageId?: string;
  message: string;
  link?: string;
  pageAccessToken?: string;
}): Promise<unknown> {
  const pageId = args.pageId || config.facebook.pageId;
  if (!pageId) throw new Error("Aucune Page cible : passez `pageId` ou définissez FACEBOOK_PAGE_ID.");
  const token = args.pageAccessToken || config.facebook.accessToken;

  const url = new URL(`${GRAPH_BASE()}/${pageId}/feed`);
  url.searchParams.set("access_token", token);
  url.searchParams.set("message", args.message);
  if (args.link) url.searchParams.set("link", args.link);

  const res = await fetch(url, { method: "POST" });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(`Échec du post (${res.status}): ${(data as GraphError).error?.message ?? ""}`);
  }
  return data;
}


/* ------------------------- Vidéos / commentaires ------------------------- */
export async function listVideos(pageId?: string): Promise<unknown> {
  const id = pageId || config.facebook.pageId;
  if (!id) throw new Error("Aucune Page cible.");
  return graphRequest(`${id}/videos`, { params: { fields: "id,title,description,created_time,permalink_url,length,post_id,is_published,status" } });
}

export async function updateVideo(videoId: string, description: string, title?: string): Promise<unknown> {
  const params: Record<string, string> = { description };
  if (title !== undefined) params.title = title;
  try {
    return await graphRequest(videoId, { method: "POST", params });
  } catch (error) {
    // Certains Reels exposent un post_id différent de l'ID vidéo.
    throw new Error(`Impossible de modifier le Reel ${videoId}. Vérifiez l'ID vidéo/post_id et les droits Page. ${error instanceof Error ? error.message : String(error)}`);
  }
}

export async function listComments(postId: string, limit = 25): Promise<unknown> {
  return graphRequest(`${postId}/comments`, { params: { fields: "id,message,from,created_time,is_hidden", limit } });
}

export async function postComment(postId: string, message: string): Promise<unknown> {
  return graphRequest(`${postId}/comments`, { method: "POST", params: { message } });
}

export async function pinComment(commentId: string, pinned = true): Promise<unknown> {
  return graphRequest(commentId, { method: "POST", params: { is_pinned: pinned } });
}

export async function checkVideoVisibility(videoId: string): Promise<unknown> {
  return graphRequest(videoId, { params: { fields: "id,title,description,permalink_url,is_published,status,privacy,created_time,post_id" } });
}
